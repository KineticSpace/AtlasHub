/*!
 * Atlas Hub v2.0
 * https://github.com/KineticSpaceInc/AtlasHub/
 * (c) 2026 Kinetic Space Inc.
 * Released under MIT & GPL-3.0 License
 */

# 🚀 DEPLOYMENT - CORRER ATLASHUB EN LA NUBE

AtlasHub 2.0 funciona en cualquier plataforma gratuita o de pago.

---

## ☁️ OPCIÓN 1: REPLIT (MÁS FÁCIL - GRATIS)

### Paso 1: Ir a Replit
- Abre https://replit.com
- Click en "Sign up"
- Crea cuenta con GitHub (recomendado)

### Paso 2: Importar desde GitHub
```
"Import from GitHub" 
→ https://github.com/KineticSpaceInc/AtlasHub
```

### Paso 3: Configurar
Replit abrirá el proyecto automáticamente.

En la pestaña "Secrets", agregar:
```
OWNER_ID = 5491234567890@c.us
```

### Paso 4: Iniciar
Click en "Run" y espera.

**Ventajas:**
- ✅ Totalmente gratis
- ✅ Funciona 24/7 (con plan gratis hay límites)
- ✅ No necesitas terminal
- ✅ Interfaz visual

**Desventajas:**
- ⚠️ Plan gratis tiene límites de uptime
- ⚠️ La base de datos se resetea cada cierto tiempo

---

## 🟢 OPCIÓN 2: RAILWAY (RECOMENDADO - GRATIS)

### Paso 1: Ir a Railway
- Abre https://railway.app
- Click en "Start Project"
- "Deploy from GitHub" (conecta tu cuenta)

### Paso 2: Seleccionar repo
- Selecciona: `KineticSpaceInc/AtlasHub`
- Confirma

### Paso 3: Configurar variables
En "Variables", agregar:
```
OWNER_ID=5491234567890@c.us
NODE_ENV=production
```

### Paso 4: Deploy automático
Railway automáticamente:
- ✅ Descarga el código
- ✅ Ejecuta `npm install`
- ✅ Inicia con `npm start`

**Ventajas:**
- ✅ Gratis ($5 crédito mensual)
- ✅ Uptime 24/7
- ✅ Persistencia de datos
- ✅ Muy rápido

**Desventajas:**
- ⚠️ Requiere verificación

---

## 🟦 OPCIÓN 3: HEROKU (ANTES ERA GRATIS, AHORA PAGO)

### Paso 1: Instalar Heroku CLI
```bash
npm install -g heroku
```

### Paso 2: Login
```bash
heroku login
```

### Paso 3: Crear app
```bash
heroku create tu-app-atlashub
```

### Paso 4: Configurar variables
```bash
heroku config:set OWNER_ID=5491234567890@c.us
heroku config:set NODE_ENV=production
```

### Paso 5: Deploy
```bash
git push heroku main
```

**Nota:** Heroku ya no es gratis. Considera Railway en su lugar.

---

## 🐳 OPCIÓN 4: DOCKER (AVANZADO)

Si quieres usar Docker, crea `Dockerfile`:

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install --break-system-packages

COPY . .

ENV NODE_ENV=production
EXPOSE 3000

CMD ["npm", "start"]
```

Luego:
```bash
docker build -t atlashub .
docker run -e OWNER_ID=5491234567890@c.us atlashub
```

---

## 📊 OPCIÓN 5: VPS (CONTROL TOTAL)

Si tienes un VPS (DigitalOcean, Linode, AWS):

### Paso 1: SSH al servidor
```bash
ssh root@tu-ip
```

### Paso 2: Instalar Node.js
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### Paso 3: Clonar AtlasHub
```bash
cd /var/www
git clone https://github.com/KineticSpaceInc/AtlasHub.git
cd AtlasHub
```

### Paso 4: Instalar dependencias
```bash
npm install --break-system-packages
```

### Paso 5: Configurar
```bash
nano .env
# Editar OWNER_ID
```

### Paso 6: Usar PM2 (mantener activo)
```bash
npm install -g pm2
pm2 start index.js --name atlashub
pm2 startup
pm2 save
```

### Paso 7: Nginx (reverso proxy - opcional)
```nginx
server {
    listen 80;
    server_name tu-dominio.com;

    location / {
        proxy_pass http://localhost:3000;
    }
}
```

---

## 🔄 ACTUALIZAR CÓDIGO EN PRODUCCIÓN

Si ya está deployado y quieres actualizar:

### Railway/Heroku:
```bash
git push heroku main
# (Auto-deployment)
```

### VPS:
```bash
cd /var/www/AtlasHub
git pull origin main
npm install
pm2 restart atlashub
```

### Replit:
- Click en "Pull from GitHub"
- Automáticamente se actualiza

---

## 💾 BACKUP DE BASE DE DATOS

La BD está en `./data/atlashub.db`

### Descargar BD (Railway):
```bash
railway run cat data/atlashub.db > backup.db
```

### Restaurar:
```bash
railway run cp backup.db data/atlashub.db
```

---

## 📈 MONITOREO

### Ver logs (Railway):
Dashboard → "Logs"

### Ver logs (VPS):
```bash
pm2 logs atlashub
```

### Ver logs (Replit):
Consola en la parte derecha

---

## 🆚 COMPARATIVA

| Platform | Precio | Uptime | Facilidad | Persistencia |
|----------|--------|--------|-----------|--------------|
| **Replit** | Gratis | ⚠️ Limitado | ⭐⭐⭐⭐⭐ | ❌ |
| **Railway** | $5/mes | ✅ 24/7 | ⭐⭐⭐⭐⭐ | ✅ |
| **Heroku** | $7/mes | ✅ 24/7 | ⭐⭐⭐⭐ | ✅ |
| **Docker** | Variable | ✅ 24/7 | ⭐⭐ | ✅ |
| **VPS** | $5-20/mes | ✅ 24/7 | ⭐⭐ | ✅ |

**Mi recomendación:** Railway (mejor relación precio-facilidad)

---

## 🎯 RESUMEN

1. **Para probar:** Replit o local
2. **Para producción:** Railway (mejor precio)
3. **Para control total:** VPS

**Todos los métodos funcionan PERFECTAMENTE con AtlasHub 2.0** ✅

---

Hecho con ❤️ por **Kinetic Space Inc.**
