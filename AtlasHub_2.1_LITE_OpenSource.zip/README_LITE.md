# 🚀 AtlasHub Lite - Open Source Edition

**AtlasHub Lite** es la versión simplificada y open source del popular bot de WhatsApp **AtlasHub**.

## ✨ Características

- ✅ **7 Juegos de azar** clásicos
- ✅ **Sistema económico** con work y daily
- ✅ **Leaderboard** global
- ✅ **Panel web** en tiempo real
- ✅ **Fácil de instalar** y personalizar
- ✅ **100% Código Abierto** (MIT & GPL-3.0)

## 🎮 Juegos Incluidos

1. **Cara o Cruz** - 50% de ganar
2. **Dados** - 1 en 6 probabilidad
3. **Ruleta** - 1 en 37 probabilidad
4. **Mayor/Menor** - 50% de ganar
5. **Tragamonedas** - 4.6% de ganar
6. **Blackjack** - 45% de ganar
7. **Lotería** - 1% de ganar

## 📦 Instalación

### Requisitos
- Node.js v18+
- npm v9+
- WhatsApp (cuenta personal)

### Pasos

```bash
# 1. Clonar
git clone https://github.com/KineticSpaceInc/AtlasHub-Lite.git
cd AtlasHub-Lite

# 2. Instalar dependencias
npm install

# 3. Configurar
nano .env  # Editar con tu número de WhatsApp

# 4. Iniciar
npm start

# 5. Escanear QR
# Abre https://web.whatsapp.com en tu navegador
# Escanea el código QR que aparece en la terminal
```

## 💻 Comandos

### Economía
```
!balance       - Ver dinero
!daily         - Ganar $1000 diarios
!work [tipo]   - Trabajar (farmer, miner, builder, hacker, trader)
```

### Juegos
```
!coinflip <apuesta> [cara/cruz]
!dice <apuesta> [1-6]
!roulette <apuesta> <0-36>
!higherlow <apuesta> [high/low]
!slots <apuesta>
!blackjack <apuesta>
!lottery <apuesta> [numeros]
```

### Utilidad
```
!help           - Ver todos los comandos
!leaderboard    - Top 10 usuarios
!rank           - Tu posición
!ping           - Verificar conexión
```

## 🌐 Panel Web

Accede a http://localhost:3000 para ver:
- 📊 Estadísticas en tiempo real
- 🏆 Ranking de usuarios
- 💰 Balances totales
- 📈 Gráficos

## ⚙️ Configuración

Edita `.env`:

```env
BOT_NAME=AtlasHub
BOT_VERSION=2.1.0
BOT_PREFIX=!
OWNER_ID=5491234567890@c.us  # Tu número de WhatsApp
PORT=3000
```

## 🔧 Personalización

### Cambiar prefix
En `.env`:
```env
BOT_PREFIX=?
```

### Agregar tus propios comandos
Edita `core/commands.js` y agrega tu comando en el método `execute()`.

### Cambiar premios de juegos
En `core/economy.js` modifica los valores de `multiplier` en la clase `GamesEngine`.

## 📁 Estructura

```
AtlasHub-Lite/
├── core/
│   ├── db.js          - Base de datos
│   ├── economy.js     - Sistema económico
│   ├── games.js       - Juegos
│   ├── commands.js    - Comandos
│   ├── utils.js       - Utilidades
│   └── logger.js      - Logging
├── panel/
│   └── server.js      - Panel web
├── index.js           - Programa principal
├── package.json       - Dependencias
└── .env              - Configuración
```

## 🚀 Deployment

### Railway (Recomendado)
1. Crea cuenta en https://railway.app
2. Conecta tu GitHub
3. Selecciona este repositorio
4. Configura variables en Railway
5. ¡Listo! Correrá 24/7

### Heroku
```bash
heroku login
heroku create tu-app-name
git push heroku main
```

### VPS/Servidor Dedicado
```bash
npm install -g pm2
pm2 start index.js --name atlashub
pm2 startup
pm2 save
```

## 🐛 Troubleshooting

### "Cannot find module"
```bash
npm install
```

### "Código QR no funciona"
```bash
rm -rf .wwebjs_auth
npm start
```

### "Puerto 3000 en uso"
Edita `.env` y cambia PORT a otro número (ej: 3001)

## 📝 Licencia

MIT & GPL-3.0

## 🤝 Contribuir

Las contribuciones son bienvenidas!

1. Fork el proyecto
2. Crea tu rama (`git checkout -b feature/mejora`)
3. Commit tus cambios (`git commit -am 'Agrego mejora'`)
4. Push a la rama (`git push origin feature/mejora`)
5. Abre un Pull Request

## 📞 Soporte

- 🐛 Issues: https://github.com/KineticSpaceInc/AtlasHub-Lite/issues
- 💬 Discussions: https://github.com/KineticSpaceInc/AtlasHub-Lite/discussions

## 🎉 Créditos

**AtlasHub** fue creado por **Kinetic Space Inc.**

Versión Lite: Open Source Edition

---

⭐ Si te gusta el proyecto, dale una estrella en GitHub!

*Hecho con ❤️ por la comunidad*
