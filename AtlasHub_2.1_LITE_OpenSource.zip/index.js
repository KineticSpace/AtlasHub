/*!
 * Atlas Hub v2.1
 * https://github.com/KineticSpaceInc/AtlasHub/
 * (c) 2026 Kinetic Space Inc.
 * Released under MIT & GPL-3.0 License
 */

import pkg from 'whatsapp-web.js';
const { Client, LocalAuth, MessageMedia } = pkg;

import qrcode from 'qrcode-terminal';
import DatabaseManager from './core/db.js';
import CommandHandler from './core/commands.js';
import EconomySystem from './core/economy.js';
import GamesEngine from './core/games.js';
import UtilityManager from './core/utils.js';
import { logger } from './core/logger.js';
import WebPanel from './panel/server.js';

class AtlasHub {
  constructor() {
    this.client = new Client({
      authStrategy: new LocalAuth(),
      puppeteer: {
        args: ['--no-sandbox', '--disable-setuid-sandbox']
      }
    });

    this.db = new DatabaseManager();
    this.economy = new EconomySystem(this.db);
    this.games = new GamesEngine(this.db);
    this.utils = new UtilityManager();
    this.commands = new CommandHandler(this.db, this.economy, this.games, this.utils);
    this.webPanel = new WebPanel(this.db);
    
    this.config = {
      prefix: '!',
      ownerID: '1234567890@c.us',
      botName: 'AtlasHub',
      version: '2.1.0',
      startTime: Date.now()
    };

    this.setupEvents();
  }

  setupEvents() {
    this.client.on('qr', (qr) => {
      logger.info('📱 Escanea este código QR con WhatsApp:');
      qrcode.generate(qr, { small: true });
    });

    this.client.on('ready', () => {
      logger.success('✅ ✅ AtlasHub 2.1 está listo!');
      logger.info(`🎯 Cuenta: ${this.client.info.pushname}`);
      logger.success(`🔗 Panel web: http://localhost:3000`);
      logger.success(`📌 Versión: ${this.config.version}`);
      logger.success(`🎮 ${Object.keys(this.games.games).length} Juegos disponibles`);
    });

    this.client.on('message', (msg) => this.handleMessage(msg));
    this.client.on('message_ack', (msg, ack) => this.handleMessageAck(msg, ack));
    
    this.client.on('disconnected', (reason) => {
      logger.error(`❌ Desconectado: ${reason}`);
      process.exit(1);
    });
  }

  async handleMessage(message) {
    try {
      const content = message.body.trim();
      
      if (message.from === this.client.info.wid?.user) return;

      await this.db.updateUserActivity(message.from);

      if (content.startsWith(this.config.prefix)) {
        await this.commands.execute(message, this.client, this.config);
      }

      await this.handlePassiveFeatures(message);

    } catch (error) {
      logger.error(`Error en handleMessage: ${error.message}`);
    }
  }

  async handleMessageAck(message, ack) {
    if (ack === 3) {
      logger.debug(`✓ Mensaje leído: ${message.id._serialized}`);
    }
  }

  async handlePassiveFeatures(message) {
    const text = message.body.toLowerCase();
    
    if (text.includes('bot') || text.includes('atlashub')) {
      const reactions = ['👋', '🤖', '⚡', '🎯', '💎', '🏆'];
      await message.react(reactions[Math.floor(Math.random() * reactions.length)]);
    }
  }

  async start() {
    try {
      logger.info('🚀 Iniciando AtlasHub 2.1...');
      await this.db.init();
      logger.success('✅ Base de datos inicializada');
      
      this.webPanel.start(3000);
      logger.success('✅ Panel web iniciado');
      
      await this.client.initialize();
    } catch (error) {
      logger.error(`❌ Error al iniciar: ${error.message}`);
      process.exit(1);
    }
  }

  async shutdown() {
    logger.warn('⏹️ Apagando AtlasHub...');
    await this.client.destroy();
    await this.db.close();
    process.exit(0);
  }
}

const bot = new AtlasHub();
bot.start().catch((err) => {
  logger.error(`❌ Error fatal: ${err.message}`);
  process.exit(1);
});

process.on('SIGINT', () => bot.shutdown());
process.on('SIGTERM', () => bot.shutdown());

export default AtlasHub;
