/*!
 * Atlas Hub Lite - Games Module
 * Versión Open Source con 7 juegos básicos
 */

import { logger } from './logger.js';

class GamesEngine {
  constructor(db) {
    this.db = db;
    this.games = {
      coinflip: { chance: 0.5, multiplier: 1, name: 'Cara o Cruz' },
      dice: { chance: 1/6, multiplier: 5, name: 'Dados' },
      roulette: { chance: 1/37, multiplier: 35, name: 'Ruleta' },
      higherlow: { chance: 0.5, multiplier: 2, name: 'Mayor/Menor' },
      slots: { chance: 0.046, multiplier: 10, name: 'Tragamonedas' },
      blackjack: { chance: 0.45, multiplier: 1.5, name: 'Blackjack' },
      lottery: { chance: 0.01, multiplier: 50, name: 'Lotería' }
    };
  }

  async coinflip(userId, bet, choice = 'heads') {
    try {
      const user = await this.db.getUser(userId);
      if (!user || user.balance < bet) return { success: false, message: '❌ Dinero insuficiente' };

      const flip = Math.random() < 0.5 ? 'heads' : 'tails';
      const won = flip === choice.toLowerCase();

      if (won) {
        await this.db.addBalance(userId, bet);
        return { success: true, won: true, result: flip === 'heads' ? '🪙 CARA' : '🪙 CRUZ', winnings: bet, newBalance: user.balance + bet };
      } else {
        await this.db.removeBalance(userId, bet);
        return { success: true, won: false, result: flip === 'heads' ? '🪙 CARA' : '🪙 CRUZ', loss: bet, newBalance: user.balance - bet };
      }
    } catch (error) {
      logger.error(`Error en coinflip: ${error.message}`);
      return { success: false, message: 'Error en el juego' };
    }
  }

  async dice(userId, bet, prediction = null) {
    try {
      const user = await this.db.getUser(userId);
      if (!user || user.balance < bet) return { success: false, message: '❌ Dinero insuficiente' };

      const roll = Math.floor(Math.random() * 6) + 1;
      const won = !prediction || roll === parseInt(prediction);

      if (won) {
        const winnings = Math.floor(bet * 5);
        await this.db.addBalance(userId, winnings);
        return { success: true, won: true, roll: `🎲 ${roll}`, winnings, newBalance: user.balance + winnings };
      } else {
        await this.db.removeBalance(userId, bet);
        return { success: true, won: false, roll: `🎲 ${roll}`, loss: bet, newBalance: user.balance - bet };
      }
    } catch (error) {
      logger.error(`Error en dice: ${error.message}`);
      return { success: false, message: 'Error en el juego' };
    }
  }

  async roulette(userId, bet, prediction) {
    try {
      const user = await this.db.getUser(userId);
      if (!user || user.balance < bet) return { success: false, message: '❌ Dinero insuficiente' };

      const spin = Math.floor(Math.random() * 37);
      const won = spin === parseInt(prediction);

      if (won) {
        const winnings = Math.floor(bet * 35);
        await this.db.addBalance(userId, winnings);
        return { success: true, won: true, spin: `🎡 ${spin}`, winnings, newBalance: user.balance + winnings };
      } else {
        await this.db.removeBalance(userId, bet);
        return { success: true, won: false, spin: `🎡 ${spin}`, loss: bet, newBalance: user.balance - bet };
      }
    } catch (error) {
      logger.error(`Error en roulette: ${error.message}`);
      return { success: false, message: 'Error en el juego' };
    }
  }

  async higherlow(userId, bet, guess) {
    try {
      const user = await this.db.getUser(userId);
      if (!user || user.balance < bet) return { success: false, message: '❌ Dinero insuficiente' };

      const card = Math.floor(Math.random() * 13) + 1;
      const isHigh = card >= 7;
      const won = (guess.toLowerCase() === 'high' && isHigh) || (guess.toLowerCase() === 'low' && !isHigh);

      if (won) {
        const winnings = Math.floor(bet * 2);
        await this.db.addBalance(userId, winnings);
        return { success: true, won: true, card: `🃏 ${card}`, winnings, newBalance: user.balance + winnings };
      } else {
        await this.db.removeBalance(userId, bet);
        return { success: true, won: false, card: `🃏 ${card}`, loss: bet, newBalance: user.balance - bet };
      }
    } catch (error) {
      logger.error(`Error en higherlow: ${error.message}`);
      return { success: false, message: 'Error en el juego' };
    }
  }

  async slots(userId, bet) {
    try {
      const user = await this.db.getUser(userId);
      if (!user || user.balance < bet) return { success: false, message: '❌ Dinero insuficiente' };

      const symbols = ['🍎', '🍊', '🍋', '🍌', '🍓', '⭐'];
      const reel1 = symbols[Math.floor(Math.random() * symbols.length)];
      const reel2 = symbols[Math.floor(Math.random() * symbols.length)];
      const reel3 = symbols[Math.floor(Math.random() * symbols.length)];

      const won = reel1 === reel2 && reel2 === reel3;

      if (won) {
        const winnings = Math.floor(bet * 10);
        await this.db.addBalance(userId, winnings);
        return { success: true, won: true, reels: `${reel1} ${reel2} ${reel3}`, winnings, newBalance: user.balance + winnings };
      } else {
        await this.db.removeBalance(userId, bet);
        return { success: true, won: false, reels: `${reel1} ${reel2} ${reel3}`, loss: bet, newBalance: user.balance - bet };
      }
    } catch (error) {
      logger.error(`Error en slots: ${error.message}`);
      return { success: false, message: 'Error en el juego' };
    }
  }

  async blackjack(userId, bet) {
    try {
      const user = await this.db.getUser(userId);
      if (!user || user.balance < bet) return { success: false, message: '❌ Dinero insuficiente' };

      const getCardValue = (card) => {
        if (card === 'A') return 11;
        if (['K', 'Q', 'J'].includes(card)) return 10;
        return parseInt(card);
      };

      const getRandomCard = () => {
        const cards = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
        return cards[Math.floor(Math.random() * cards.length)];
      };

      const playerCard1 = getRandomCard();
      const playerCard2 = getRandomCard();
      const dealerCard1 = getRandomCard();

      const playerValue = getCardValue(playerCard1) + getCardValue(playerCard2);
      const dealerValue = getCardValue(dealerCard1);

      let won = false;

      if (playerValue > 21) {
        won = false;
      } else if (playerValue === 21) {
        won = true;
      } else if (dealerValue > 21) {
        won = true;
      } else if (playerValue > dealerValue) {
        won = true;
      }

      if (won) {
        const winnings = Math.floor(bet * 1.5);
        await this.db.addBalance(userId, winnings);
        return { success: true, won: true, playerCards: `${playerCard1} ${playerCard2}`, playerValue, dealerCard: dealerCard1, dealerValue, winnings, newBalance: user.balance + winnings };
      } else {
        await this.db.removeBalance(userId, bet);
        return { success: true, won: false, playerCards: `${playerCard1} ${playerCard2}`, playerValue, dealerCard: dealerCard1, dealerValue, loss: bet, newBalance: user.balance - bet };
      }
    } catch (error) {
      logger.error(`Error en blackjack: ${error.message}`);
      return { success: false, message: 'Error en el juego' };
    }
  }

  async lottery(userId, bet, numbers = []) {
    try {
      const user = await this.db.getUser(userId);
      if (!user || user.balance < bet) return { success: false, message: '❌ Dinero insuficiente' };

      const winningNumbers = Array.from({ length: 6 }, () => Math.floor(Math.random() * 49) + 1);
      const matched = numbers.filter(n => winningNumbers.includes(n)).length;

      if (matched === 6) {
        const winnings = Math.floor(bet * 50);
        await this.db.addBalance(userId, winnings);
        return { success: true, won: true, matched: 6, winnings, newBalance: user.balance + winnings };
      } else {
        await this.db.removeBalance(userId, bet);
        return { success: true, won: false, matched, loss: bet, newBalance: user.balance - bet };
      }
    } catch (error) {
      logger.error(`Error en lottery: ${error.message}`);
      return { success: false, message: 'Error en el juego' };
    }
  }

  getGamesList() {
    return this.games;
  }
}

export default GamesEngine;
