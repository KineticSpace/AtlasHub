/*!
 * Atlas Hub v2.0
 * https://github.com/KineticSpaceInc/AtlasHub/
 * (c) 2026 Kinetic Space Inc.
 * Released under MIT & GPL-3.0 License
 */

import Database from 'better-sqlite3';
import { logger } from './logger.js';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, '../data');
const dbPath = path.join(dataDir, 'atlashub.db');

class DatabaseManager {
  constructor() {
    this.db = null;
  }

  async init() {
    try {
      // Crear carpeta data si no existe
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
        logger.info(`Carpeta 'data' creada en: ${dataDir}`);
      }

      this.db = new Database(dbPath, { fileMustExist: false });
      this.db.pragma('journal_mode = WAL');
      this.db.pragma('synchronous = NORMAL');
      
      await this.createTables();
      logger.success('Base de datos inicializada correctamente');
    } catch (error) {
      logger.error(`Error inicializando BD: ${error.message}`);
      throw error;
    }
  }

  async createTables() {
    const tables = [
      // Tabla de usuarios
      `CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE,
        balance BIGINT DEFAULT 0,
        bank BIGINT DEFAULT 0,
        level INTEGER DEFAULT 1,
        experience BIGINT DEFAULT 0,
        reputation INTEGER DEFAULT 0,
        lastDaily DATETIME,
        lastWork DATETIME,
        lastCrime DATETIME,
        warnings INTEGER DEFAULT 0,
        muted INTEGER DEFAULT 0,
        banned INTEGER DEFAULT 0,
        premium INTEGER DEFAULT 0,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Tabla de inventario
      `CREATE TABLE IF NOT EXISTS inventory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId TEXT NOT NULL,
        itemId TEXT NOT NULL,
        quantity INTEGER DEFAULT 1,
        acquiredAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(userId) REFERENCES users(id),
        UNIQUE(userId, itemId)
      )`,

      // Tabla de transacciones
      `CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fromId TEXT,
        toId TEXT,
        amount BIGINT,
        type TEXT,
        description TEXT,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(fromId) REFERENCES users(id),
        FOREIGN KEY(toId) REFERENCES users(id)
      )`,

      // Tabla de trabajos
      `CREATE TABLE IF NOT EXISTS jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId TEXT NOT NULL,
        jobType TEXT,
        earnings BIGINT,
        difficulty INTEGER,
        completedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(userId) REFERENCES users(id)
      )`,

      // Tabla de eventos
      `CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId TEXT,
        eventType TEXT,
        data JSON,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(userId) REFERENCES users(id)
      )`,

      // Tabla de modlogs (para administración)
      `CREATE TABLE IF NOT EXISTS modlogs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        modId TEXT,
        userId TEXT,
        action TEXT,
        reason TEXT,
        duration INTEGER,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(modId) REFERENCES users(id),
        FOREIGN KEY(userId) REFERENCES users(id)
      )`,

      // Tabla de configuración de grupos
      `CREATE TABLE IF NOT EXISTS groupConfig (
        id TEXT PRIMARY KEY,
        groupName TEXT,
        prefix TEXT DEFAULT '!',
        allowEconomy INTEGER DEFAULT 1,
        allowGames INTEGER DEFAULT 1,
        allowNsfw INTEGER DEFAULT 0,
        language TEXT DEFAULT 'es',
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Tabla de logros
      `CREATE TABLE IF NOT EXISTS achievements (
        id TEXT PRIMARY KEY,
        userId TEXT NOT NULL,
        achievementId TEXT,
        unlockedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(userId) REFERENCES users(id),
        UNIQUE(userId, achievementId)
      )`
    ];

    for (const table of tables) {
      try {
        this.db.exec(table);
      } catch (error) {
        logger.error(`Error creando tabla: ${error.message}`);
      }
    }
  }

  // ========== USUARIO ==========
  async getUser(userId) {
    try {
      const stmt = this.db.prepare('SELECT * FROM users WHERE id = ?');
      return stmt.get(userId);
    } catch (error) {
      logger.error(`Error obteniendo usuario: ${error.message}`);
      return null;
    }
  }

  async createUser(userId, username = null) {
    try {
      const stmt = this.db.prepare(
        'INSERT OR IGNORE INTO users (id, username) VALUES (?, ?)'
      );
      stmt.run(userId, username || userId);
      return this.getUser(userId);
    } catch (error) {
      logger.error(`Error creando usuario: ${error.message}`);
      return null;
    }
  }

  async updateUserActivity(userId) {
    try {
      const user = await this.getUser(userId);
      if (!user) {
        await this.createUser(userId);
      }
    } catch (error) {
      logger.error(`Error actualizando actividad: ${error.message}`);
    }
  }

  async addBalance(userId, amount) {
    try {
      const stmt = this.db.prepare(
        'UPDATE users SET balance = balance + ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?'
      );
      stmt.run(amount, userId);
      return this.getUser(userId);
    } catch (error) {
      logger.error(`Error añadiendo balance: ${error.message}`);
      return null;
    }
  }

  async removeBalance(userId, amount) {
    try {
      const user = await this.getUser(userId);
      if (!user || user.balance < amount) return null;
      
      return this.addBalance(userId, -amount);
    } catch (error) {
      logger.error(`Error removiendo balance: ${error.message}`);
      return null;
    }
  }

  async addExperience(userId, exp) {
    try {
      const stmt = this.db.prepare(
        'UPDATE users SET experience = experience + ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?'
      );
      stmt.run(exp, userId);
      return this.getUser(userId);
    } catch (error) {
      logger.error(`Error añadiendo experiencia: ${error.message}`);
      return null;
    }
  }

  async addReputation(userId, rep) {
    try {
      const stmt = this.db.prepare(
        'UPDATE users SET reputation = reputation + ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?'
      );
      stmt.run(rep, userId);
      return this.getUser(userId);
    } catch (error) {
      logger.error(`Error añadiendo reputación: ${error.message}`);
      return null;
    }
  }

  async getLeaderboard(limit = 10, type = 'balance') {
    try {
      const stmt = this.db.prepare(
        `SELECT id, username, balance, experience, level, reputation 
         FROM users 
         ORDER BY ${type} DESC 
         LIMIT ?`
      );
      return stmt.all(limit);
    } catch (error) {
      logger.error(`Error obteniendo leaderboard: ${error.message}`);
      return [];
    }
  }

  async getUserRank(userId, type = 'balance') {
    try {
      const stmt = this.db.prepare(
        `SELECT COUNT(*) as rank FROM users WHERE ${type} > (SELECT ${type} FROM users WHERE id = ?)`
      );
      const result = stmt.get(userId);
      return result.rank + 1;
    } catch (error) {
      logger.error(`Error obteniendo rank: ${error.message}`);
      return 0;
    }
  }

  // ========== TRANSACCIONES ==========
  async transferBalance(fromId, toId, amount, description = '') {
    try {
      const from = await this.getUser(fromId);
      if (!from || from.balance < amount) return null;

      await this.removeBalance(fromId, amount);
      await this.addBalance(toId, amount);

      const stmt = this.db.prepare(
        'INSERT INTO transactions (fromId, toId, amount, type, description) VALUES (?, ?, ?, ?, ?)'
      );
      stmt.run(fromId, toId, amount, 'transfer', description);

      return { success: true, amount };
    } catch (error) {
      logger.error(`Error transfiriendo balance: ${error.message}`);
      return null;
    }
  }

  // ========== INVENTARIO ==========
  async addItem(userId, itemId, quantity = 1) {
    try {
      const stmt = this.db.prepare(
        `INSERT INTO inventory (userId, itemId, quantity) 
         VALUES (?, ?, ?) 
         ON CONFLICT(userId, itemId) 
         DO UPDATE SET quantity = quantity + ?`
      );
      stmt.run(userId, itemId, quantity, quantity);
      return true;
    } catch (error) {
      logger.error(`Error añadiendo item: ${error.message}`);
      return false;
    }
  }

  async removeItem(userId, itemId, quantity = 1) {
    try {
      const stmt = this.db.prepare(
        'UPDATE inventory SET quantity = quantity - ? WHERE userId = ? AND itemId = ?'
      );
      stmt.run(quantity, userId, itemId);
      return true;
    } catch (error) {
      logger.error(`Error removiendo item: ${error.message}`);
      return false;
    }
  }

  async getInventory(userId) {
    try {
      const stmt = this.db.prepare('SELECT * FROM inventory WHERE userId = ?');
      return stmt.all(userId);
    } catch (error) {
      logger.error(`Error obteniendo inventario: ${error.message}`);
      return [];
    }
  }

  // ========== CIERRE ==========
  async close() {
    if (this.db) {
      this.db.close();
      logger.info('Conexión a BD cerrada');
    }
  }
}

export default DatabaseManager;
