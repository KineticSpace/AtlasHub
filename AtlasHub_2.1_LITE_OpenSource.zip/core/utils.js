/*!
 * Atlas Hub v2.0
 * https://github.com/KineticSpaceInc/AtlasHub/
 * (c) 2026 Kinetic Space Inc.
 * Released under MIT & GPL-3.0 License
 */

import { logger } from './logger.js';
import axios from 'axios';

class UtilityManager {
  constructor() {
    this.cache = new Map();
    this.cacheTimeout = 3600000; // 1 hora
  }

  // ========== TEXT UTILITIES ==========
  formatNumber(num) {
    return new Intl.NumberFormat('es-ES').format(num);
  }

  formatCurrency(amount) {
    return `$${this.formatNumber(amount)}`;
  }

  capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }

  generateId() {
    return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // ========== PROGRESS BAR ==========
  createProgressBar(current, max, length = 20) {
    const percentage = Math.min(current / max, 1);
    const filled = Math.floor(length * percentage);
    const empty = length - filled;

    const bar = '█'.repeat(filled) + '░'.repeat(empty);
    const percent = Math.round(percentage * 100);

    return `[${bar}] ${percent}%`;
  }

  // ========== EMBED/CARD HELPERS ==========
  createUserCard(user) {
    const levelExp = user.level * 1000;
    const expProgress = user.experience % levelExp;
    const progressBar = this.createProgressBar(expProgress, levelExp, 15);

    return `
╔════════════════════════════════════╗
║ **${user.username || user.id}**
║ 💰 Balance: $${this.formatNumber(user.balance)}
║ 🏦 Bank: $${this.formatNumber(user.bank)}
║ 📊 Level: ${user.level}
║ ⭐ Experience: ${this.formatNumber(user.experience)}
║ ${progressBar}
║ 🏅 Reputation: ${user.reputation}
║ ⚠️  Warnings: ${user.warnings}
╚════════════════════════════════════╝
    `;
  }

  // ========== TIME UTILITIES ==========
  getTimeUntilDaily(lastDaily) {
    if (!lastDaily) return 'Disponible ahora';

    const now = Date.now();
    const next = new Date(lastDaily).getTime() + 86400000;
    const diff = next - now;

    if (diff <= 0) return 'Disponible ahora';

    const hours = Math.floor(diff / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);

    return `${hours}h ${minutes}m`;
  }

  secondsToTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    const parts = [];
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    if (secs > 0) parts.push(`${secs}s`);

    return parts.join(' ') || '0s';
  }

  // ========== VALIDATION ==========
  isValidUserId(id) {
    return /^\d+@c\.us$/.test(id);
  }

  isValidNumber(num) {
    return !isNaN(num) && isFinite(num) && num > 0;
  }

  parseArgs(text, expectedTypes = []) {
    const args = text.trim().split(/\s+/);
    const parsed = [];

    for (let i = 0; i < expectedTypes.length && i < args.length; i++) {
      const type = expectedTypes[i];
      const arg = args[i];

      switch (type) {
        case 'number':
          parsed.push(parseInt(arg));
          break;
        case 'string':
          parsed.push(arg);
          break;
        case 'user':
          parsed.push(arg.replace(/[@_]/g, ''));
          break;
        default:
          parsed.push(arg);
      }
    }

    return parsed;
  }

  // ========== API CALLS ==========
  async fetchWithCache(url, cacheKey = null) {
    try {
      const key = cacheKey || url;

      if (this.cache.has(key)) {
        const cached = this.cache.get(key);
        if (Date.now() - cached.timestamp < this.cacheTimeout) {
          return cached.data;
        }
      }

      const response = await axios.get(url, { timeout: 5000 });
      this.cache.set(key, {
        data: response.data,
        timestamp: Date.now()
      });

      return response.data;
    } catch (error) {
      logger.error(`Error fetching ${url}: ${error.message}`);
      return null;
    }
  }

  // ========== RANDOM UTILITIES ==========
  randomFromArray(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  randomRange(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  chance(percentage) {
    return Math.random() * 100 < percentage;
  }

  // ========== DECORATIVE FUNCTIONS ==========
  createBorder(text, char = '═', width = 40) {
    const padding = Math.max(0, (width - text.length) / 2);
    const left = char.repeat(Math.floor(padding));
    const right = char.repeat(Math.ceil(padding));
    return `${left}${text}${right}`;
  }

  createBox(content, title = '') {
    let box = '╔';
    if (title) {
      box += '═ ' + title + ' ';
      box += '═'.repeat(Math.max(0, 30 - title.length));
    } else {
      box += '═'.repeat(32);
    }
    box += '╗\n';

    box += content + '\n';

    box += '╚' + '═'.repeat(32) + '╝';

    return box;
  }

  // ========== IMAGE UTILITIES ==========
  async createAvatarUrl(userId) {
    // Genera avatar usando API externa
    return `https://api.dicebear.com/7.x/avataaars/svg?seed=${userId}`;
  }

  // ========== VERSION INFO ==========
  getVersionInfo() {
    return {
      name: 'AtlasHub',
      version: '2.0.0',
      author: 'Kinetic Space Inc.',
      license: 'MIT & GPL-3.0',
      github: 'https://github.com/KineticSpaceInc/AtlasHub/'
    };
  }
}

export default UtilityManager;
