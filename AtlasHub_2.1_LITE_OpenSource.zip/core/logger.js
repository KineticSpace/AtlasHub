/*!
 * Atlas Hub v2.0
 * https://github.com/KineticSpaceInc/AtlasHub/
 * (c) 2026 Kinetic Space Inc.
 * Released under MIT & GPL-3.0 License
 */

import moment from 'moment';
import 'moment/locale/es.js';

moment.locale('es');

class Logger {
  constructor() {
    this.colors = {
      reset: '\x1b[0m',
      bright: '\x1b[1m',
      dim: '\x1b[2m',
      red: '\x1b[31m',
      green: '\x1b[32m',
      yellow: '\x1b[33m',
      blue: '\x1b[34m',
      cyan: '\x1b[36m',
      white: '\x1b[37m'
    };
  }

  getTimestamp() {
    return moment().format('DD/MM/YYYY HH:mm:ss');
  }

  log(message, color = 'white') {
    const timestamp = this.getTimestamp();
    console.log(`${this.colors[color]}[${timestamp}] ${message}${this.colors.reset}`);
  }

  info(message) {
    this.log(`ℹ️  ${message}`, 'cyan');
  }

  success(message) {
    this.log(`✅ ${message}`, 'green');
  }

  error(message) {
    this.log(`❌ ${message}`, 'red');
  }

  warn(message) {
    this.log(`⚠️  ${message}`, 'yellow');
  }

  debug(message) {
    if (process.env.DEBUG === 'true') {
      this.log(`🐛 ${message}`, 'blue');
    }
  }

  command(user, cmd) {
    this.log(`📝 Comando: ${cmd} | Usuario: ${user}`, 'yellow');
  }
}

export const logger = new Logger();
export default Logger;
