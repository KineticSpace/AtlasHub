/*!
 * Atlas Hub v2.0
 * https://github.com/KineticSpaceInc/AtlasHub/
 * (c) 2026 Kinetic Space Inc.
 * Released under MIT & GPL-3.0 License
 */

import { logger } from './logger.js';

class EconomySystem {
  constructor(db) {
    this.db = db;
    
    // Configuración de trabajos (BALANCEADO)
    this.jobs = {
      farmer: { earnings: 150, time: 30, difficulty: 1, emoji: '👨‍🌾' },
      miner: { earnings: 300, time: 60, difficulty: 2, emoji: '⛏️' },
      builder: { earnings: 400, time: 90, difficulty: 3, emoji: '👷' },
      hacker: { earnings: 600, time: 120, difficulty: 4, emoji: '💻' },
      trader: { earnings: 800, time: 180, difficulty: 5, emoji: '📈' }
    };

    // Crímenes (riesgo/recompensa balanceado)
    this.crimes = {
      pickpocket: { earnings: 50, risk: 20, time: 10, emoji: '🎭' },
      robbery: { earnings: 300, risk: 60, time: 30, emoji: '🔫' },
      fraud: { earnings: 500, risk: 50, time: 60, emoji: '💳' },
      heist: { earnings: 2000, risk: 85, time: 120, emoji: '💎' }
    };

    // Shop items (SISTEMA JUSTO)
    this.shop = {
      lootbox_common: { price: 500, rarity: 'common', emoji: '📦', rewards: { coins: [100, 300] } },
      lootbox_rare: { price: 2000, rarity: 'rare', emoji: '🎁', rewards: { coins: [500, 1500] } },
      lootbox_legendary: { price: 10000, rarity: 'legendary', emoji: '👑', rewards: { coins: [3000, 8000] } },
      pet_dog: { price: 5000, rarity: 'pet', emoji: '🐕', rewards: {} },
      pet_cat: { price: 3000, rarity: 'pet', emoji: '🐱', rewards: {} },
      multiplier_2x: { price: 15000, rarity: 'boost', emoji: '⚡', rewards: {} }
    };

    // Multas y castigos
    this.fines = {
      warning: 0,
      mute: 0,
      kick: 0,
      ban: 0
    };
  }

  // ========== TRABAJOS ==========
  async work(userId, jobType) {
    try {
      const job = this.jobs[jobType];
      if (!job) return { success: false, message: 'Trabajo no válido' };

      const user = await this.db.getUser(userId);
      if (!user) return { success: false, message: 'Usuario no encontrado' };

      // Verificar cooldown (5 minutos entre trabajos)
      if (user.lastWork) {
        const cooldown = 300000; // 5 minutos
        const timePassed = Date.now() - new Date(user.lastWork).getTime();
        if (timePassed < cooldown) {
          return { 
            success: false, 
            message: `⏱️ Espera ${Math.ceil((cooldown - timePassed) / 1000)} segundos` 
          };
        }
      }

      // Ejecutar trabajo con variabilidad
      const variance = 0.8 + Math.random() * 0.4; // 80-120% del earnings base
      const earnings = Math.floor(job.earnings * variance);

      await this.db.addBalance(userId, earnings);
      await this.db.addExperience(userId, job.difficulty * 10);

      // Actualizar lastWork
      const stmt = this.db.db.prepare('UPDATE users SET lastWork = CURRENT_TIMESTAMP WHERE id = ?');
      stmt.run(userId);

      return {
        success: true,
        earnings,
        message: `${job.emoji} Completaste el trabajo de ${jobType} y ganaste **$${earnings}**`
      };
    } catch (error) {
      logger.error(`Error en work: ${error.message}`);
      return { success: false, message: 'Error ejecutando trabajo' };
    }
  }

  // ========== CRÍMENES ==========
  async crime(userId, crimeType) {
    try {
      const crime = this.crimes[crimeType];
      if (!crime) return { success: false, message: 'Crimen no válido' };

      const user = await this.db.getUser(userId);
      if (!user) return { success: false, message: 'Usuario no encontrado' };

      // Cooldown 10 minutos
      if (user.lastCrime) {
        const cooldown = 600000;
        const timePassed = Date.now() - new Date(user.lastCrime).getTime();
        if (timePassed < cooldown) {
          return { 
            success: false, 
            message: `⏱️ Espera ${Math.ceil((cooldown - timePassed) / 1000)} segundos` 
          };
        }
      }

      // Calcular éxito
      const success = Math.random() * 100 > crime.risk;

      if (success) {
        const earnings = crime.earnings;
        await this.db.addBalance(userId, earnings);
        await this.db.addExperience(userId, 20);

        const stmt = this.db.db.prepare('UPDATE users SET lastCrime = CURRENT_TIMESTAMP WHERE id = ?');
        stmt.run(userId);

        return {
          success: true,
          earnings,
          message: `${crime.emoji} ¡Crimen exitoso! Ganaste **$${earnings}** 💰`
        };
      } else {
        // Si falla, pierde dinero como multa
        const fine = Math.floor(crime.earnings * 0.5);
        await this.db.removeBalance(userId, fine);
        
        const stmt = this.db.db.prepare('UPDATE users SET warnings = warnings + 1, lastCrime = CURRENT_TIMESTAMP WHERE id = ?');
        stmt.run(userId);

        return {
          success: false,
          message: `😰 ¡Fallaste! Pagaste **$${fine}** de multa y ganaste una advertencia`
        };
      }
    } catch (error) {
      logger.error(`Error en crime: ${error.message}`);
      return { success: false, message: 'Error ejecutando crimen' };
    }
  }

  // ========== DAILY REWARD ==========
  async daily(userId) {
    try {
      const user = await this.db.getUser(userId);
      if (!user) {
        await this.db.createUser(userId);
        return this.daily(userId);
      }

      if (user.lastDaily) {
        const cooldown = 86400000; // 24 horas
        const timePassed = Date.now() - new Date(user.lastDaily).getTime();
        if (timePassed < cooldown) {
          const hoursLeft = Math.ceil((cooldown - timePassed) / 3600000);
          return { 
            success: false, 
            message: `⏰ Vuelve en ${hoursLeft} horas` 
          };
        }
      }

      const dailyReward = 1000; // Recompensa diaria fija
      await this.db.addBalance(userId, dailyReward);

      const stmt = this.db.db.prepare('UPDATE users SET lastDaily = CURRENT_TIMESTAMP WHERE id = ?');
      stmt.run(userId);

      return {
        success: true,
        earnings: dailyReward,
        message: `🎁 ¡Recompensa diaria! Recibiste **$${dailyReward}**`
      };
    } catch (error) {
      logger.error(`Error en daily: ${error.message}`);
      return { success: false, message: 'Error obteniendo recompensa diaria' };
    }
  }

  // ========== BALANCE & BANK ==========
  async getBalance(userId) {
    try {
      const user = await this.db.getUser(userId);
      return user ? user.balance : 0;
    } catch (error) {
      logger.error(`Error obteniendo balance: ${error.message}`);
      return 0;
    }
  }

  async deposit(userId, amount) {
    try {
      const user = await this.db.getUser(userId);
      if (!user || user.balance < amount) {
        return { success: false, message: 'No tienes suficiente dinero' };
      }

      await this.db.removeBalance(userId, amount);
      
      const stmt = this.db.db.prepare('UPDATE users SET bank = bank + ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?');
      stmt.run(amount, userId);

      return { success: true, message: `💳 Depositaste **$${amount}** en el banco` };
    } catch (error) {
      logger.error(`Error depositando: ${error.message}`);
      return { success: false, message: 'Error en transacción' };
    }
  }

  async withdraw(userId, amount) {
    try {
      const user = await this.db.getUser(userId);
      if (!user || user.bank < amount) {
        return { success: false, message: 'No tienes suficiente dinero en el banco' };
      }

      await this.db.addBalance(userId, amount);
      
      const stmt = this.db.db.prepare('UPDATE users SET bank = bank - ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?');
      stmt.run(amount, userId);

      return { success: true, message: `🏧 Retiraste **$${amount}** del banco` };
    } catch (error) {
      logger.error(`Error retirando: ${error.message}`);
      return { success: false, message: 'Error en transacción' };
    }
  }

  // ========== TRANSFER ==========
  async transfer(fromId, toId, amount) {
    try {
      if (amount <= 0) return { success: false, message: 'Cantidad inválida' };
      if (fromId === toId) return { success: false, message: 'No puedes transferir a ti mismo' };

      const from = await this.db.getUser(fromId);
      const to = await this.db.getUser(toId);

      if (!from || !to) return { success: false, message: 'Usuario no encontrado' };
      if (from.balance < amount) return { success: false, message: 'No tienes suficiente dinero' };

      // Cobrar impuesto (5%)
      const tax = Math.floor(amount * 0.05);
      const netAmount = amount - tax;

      await this.db.removeBalance(fromId, amount);
      await this.db.addBalance(toId, netAmount);

      return {
        success: true,
        message: `✅ Transferiste **$${amount}** (Impuesto: $${tax})`,
        details: { sent: amount, tax, received: netAmount }
      };
    } catch (error) {
      logger.error(`Error transfiriendo: ${error.message}`);
      return { success: false, message: 'Error en transacción' };
    }
  }

  // ========== SHOP ==========
  async buyItem(userId, itemId) {
    try {
      const item = this.shop[itemId];
      if (!item) return { success: false, message: 'Item no existe' };

      const user = await this.db.getUser(userId);
      if (!user || user.balance < item.price) {
        return { success: false, message: `No tienes suficiente dinero ($${item.price})` };
      }

      await this.db.removeBalance(userId, item.price);
      await this.db.addItem(userId, itemId);

      return {
        success: true,
        message: `${item.emoji} Compraste **${itemId}** por **$${item.price}**`
      };
    } catch (error) {
      logger.error(`Error comprando item: ${error.message}`);
      return { success: false, message: 'Error en compra' };
    }
  }

  getShopList() {
    const list = Object.entries(this.shop).map(([id, item]) => {
      return `${item.emoji} **${id}** - $${item.price} (${item.rarity})`;
    });
    return list.join('\n');
  }

  getJobsList() {
    const list = Object.entries(this.jobs).map(([id, job]) => {
      return `${job.emoji} **${id}** - $${job.earnings} | Dificultad: ${job.difficulty}`;
    });
    return list.join('\n');
  }

  getCrimesList() {
    const list = Object.entries(this.crimes).map(([id, crime]) => {
      return `${crime.emoji} **${id}** - $${crime.earnings} | Riesgo: ${crime.risk}%`;
    });
    return list.join('\n');
  }
}

export default EconomySystem;
