/*!
 * Atlas Hub Lite v2.1
 * Open Source Version
 * https://github.com/KineticSpaceInc/AtlasHub-Lite/
 */

import { logger } from './logger.js';

class CommandHandler {
  constructor(db, economy, games, utils) {
    this.db = db;
    this.economy = economy;
    this.games = games;
    this.utils = utils;
    this.cooldowns = new Map();
  }

  isCooldown(userId, command) {
    const key = `${userId}:${command}`;
    const now = Date.now();
    if (this.cooldowns.has(key)) {
      const lastUse = this.cooldowns.get(key);
      if (now - lastUse < 2000) return true;
    }
    return false;
  }

  setCooldown(userId, command) {
    const key = `${userId}:${command}`;
    this.cooldowns.set(key, Date.now());
  }

  async execute(message, client, config) {
    try {
      const args = message.body.slice(config.prefix.length).trim().split(/\s+/);
      const command = args[0].toLowerCase();
      const params = args.slice(1);

      if (this.isCooldown(message.from, command)) {
        return message.reply('⏰ Espera 2 segundos');
      }
      this.setCooldown(message.from, command);

      // ==================== ECONOMÍA ====================
      if (command === 'balance' || command === 'bal') {
        const user = await this.db.getUser(message.from);
        if (!user) await this.db.createUser(message.from);
        const updated = await this.db.getUser(message.from);
        message.reply(`💰 Balance: $${updated.balance.toLocaleString('es-ES')}`);
      }

      else if (command === 'daily') {
        const result = await this.economy.daily(message.from);
        message.reply(result.message);
      }

      else if (command === 'work') {
        const jobType = params[0] || 'farmer';
        const result = await this.economy.work(message.from, jobType);
        message.reply(`💼 Ganaste: $${result.earnings.toLocaleString('es-ES')}`);
      }

      // ==================== JUEGOS (LITE: 6 juegos básicos) ====================
      else if (command === 'coinflip' || command === 'cf') {
        const bet = parseInt(params[0]) || 100;
        const choice = params[1]?.toLowerCase() || 'heads';
        const result = await this.games.coinflip(message.from, bet, choice);
        if (result.won) {
          message.reply(`🎉 ¡GANASTE! $${result.winnings.toLocaleString('es-ES')}`);
        } else {
          message.reply(`😢 Perdiste $${result.loss.toLocaleString('es-ES')}`);
        }
      }

      else if (command === 'dice') {
        const bet = parseInt(params[0]) || 100;
        const result = await this.games.dice(message.from, bet);
        message.reply(`🎲 ${result.roll} - ${result.won ? '¡GANASTE!' : 'Perdiste'}`);
      }

      else if (command === 'roulette' || command === 'roul') {
        const bet = parseInt(params[0]) || 100;
        const prediction = params[1];
        const result = await this.games.roulette(message.from, bet, prediction);
        message.reply(`🎡 ${result.spin} - ${result.won ? '✅' : '❌'}`);
      }

      else if (command === 'slots') {
        const bet = parseInt(params[0]) || 100;
        const result = await this.games.slots(message.from, bet);
        message.reply(`🎰 ${result.reels}\n${result.won ? '🎉 ¡JACKPOT!' : '❌'}`);
      }

      else if (command === 'blackjack' || command === 'bj') {
        const bet = parseInt(params[0]) || 100;
        const result = await this.games.blackjack(message.from, bet);
        message.reply(`🃏 Tu mano: ${result.playerCards} (${result.playerValue})\n${result.won ? '✅ GANASTE!' : '❌ PERDISTE'}`);
      }

      else if (command === 'higherlow' || command === 'hl') {
        const bet = parseInt(params[0]) || 100;
        const guess = params[1]?.toLowerCase() || 'high';
        const result = await this.games.higherlow(message.from, bet, guess);
        message.reply(`🃏 ${result.card} - ${result.won ? '✅' : '❌'}`);
      }

      // ==================== TIENDA ====================
      else if (command === 'shop') {
        message.reply(`🛍️ TIENDA\n💎 Caja: $500\n🐾 Mascota: $3000\n⚡ Boost: $15000`);
      }

      // ==================== LEADERBOARD ====================
      else if (command === 'leaderboard' || command === 'top' || command === 'lb') {
        const top = await this.db.getLeaderboard(10);
        let msg = '🏆 TOP 10\n';
        top.forEach((user, i) => {
          msg += `${i + 1}. ${user.username || 'User'} - $${user.balance.toLocaleString('es-ES')}\n`;
        });
        message.reply(msg);
      }

      // ==================== UTILIDAD ====================
      else if (command === 'help') {
        message.reply(`
💰 ECONOMÍA: !balance, !daily, !work
🎮 JUEGOS: !coinflip, !dice, !roulette, !slots, !blackjack, !higherlow
🏆 RANKING: !leaderboard, !rank
❓ OTROS: !help, !ping
        `);
      }

      else if (command === 'ping') {
        message.reply('🏓 Pong!');
      }

      else if (command === 'rank') {
        const rank = await this.db.getUserRank(message.from);
        message.reply(`🏅 Estás en puesto #${rank}`);
      }

      else {
        message.reply(`❌ Comando no reconocido: ${command}`);
      }

    } catch (error) {
      logger.error(`Error: ${error.message}`);
      message.reply('❌ Error al ejecutar comando');
    }
  }
}

export default CommandHandler;
