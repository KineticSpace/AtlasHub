/*!
 * Atlas Hub v2.0
 * https://github.com/KineticSpaceInc/AtlasHub/
 * (c) 2026 Kinetic Space Inc.
 * Released under MIT & GPL-3.0 License
 */

import express from 'express';
import { logger } from '../core/logger.js';

class WebPanel {
  constructor(db) {
    this.db = db;
    this.app = express();
    this.setupRoutes();
  }

  setupRoutes() {
    // Middleware
    this.app.use(express.json());
    this.app.use(express.static('public'));

    // Rutas API
    this.app.get('/api/status', (req, res) => {
      res.json({
        status: 'online',
        version: '2.0.0',
        uptime: process.uptime(),
        timestamp: new Date()
      });
    });

    this.app.get('/api/stats', async (req, res) => {
      try {
        const leaderboard = await this.db.getLeaderboard(100);
        const totalBalance = leaderboard.reduce((sum, user) => sum + user.balance, 0);
        const avgBalance = Math.floor(totalBalance / leaderboard.length);

        res.json({
          totalUsers: leaderboard.length,
          totalBalance,
          avgBalance,
          topUser: leaderboard[0]
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    this.app.get('/api/leaderboard/:type?', async (req, res) => {
      try {
        const type = req.params.type || 'balance';
        const limit = parseInt(req.query.limit) || 50;
        const leaderboard = await this.db.getLeaderboard(limit, type);

        res.json(leaderboard);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    this.app.get('/api/user/:id', async (req, res) => {
      try {
        const user = await this.db.getUser(req.params.id);
        const rank = await this.db.getUserRank(req.params.id);

        if (!user) {
          return res.status(404).json({ error: 'User not found' });
        }

        res.json({ ...user, rank });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // Página principal
    this.app.get('/', (req, res) => {
      res.send(this.getDashboardHTML());
    });

    // Error handling
    this.app.use((err, req, res, next) => {
      logger.error(`Express error: ${err.message}`);
      res.status(500).json({ error: 'Internal server error' });
    });
  }

  getDashboardHTML() {
    return `
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AtlasHub 2.0 - Dashboard</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      color: #333;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }

    header {
      background: white;
      border-radius: 10px;
      padding: 30px;
      margin-bottom: 30px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
      text-align: center;
    }

    h1 {
      color: #667eea;
      margin-bottom: 10px;
      font-size: 2.5em;
    }

    .version {
      color: #999;
      font-size: 0.9em;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }

    .card {
      background: white;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .card h3 {
      color: #667eea;
      margin-bottom: 15px;
      font-size: 1.2em;
    }

    .stat-value {
      font-size: 2em;
      color: #764ba2;
      font-weight: bold;
    }

    .leaderboard {
      background: white;
      border-radius: 10px;
      padding: 30px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th {
      background: #f5f5f5;
      padding: 12px;
      text-align: left;
      border-bottom: 2px solid #667eea;
      color: #667eea;
      font-weight: 600;
    }

    td {
      padding: 12px;
      border-bottom: 1px solid #eee;
    }

    tr:hover {
      background: #f9f9f9;
    }

    .loading {
      text-align: center;
      padding: 40px;
      color: #999;
    }

    .error {
      background: #fee;
      color: #c33;
      padding: 15px;
      border-radius: 5px;
      margin: 10px 0;
    }

    footer {
      text-align: center;
      color: white;
      padding: 20px;
      margin-top: 50px;
      font-size: 0.9em;
    }

    .online-badge {
      display: inline-block;
      width: 12px;
      height: 12px;
      background: #4caf50;
      border-radius: 50%;
      margin-right: 8px;
    }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>⚡ AtlasHub 2.0</h1>
      <p class="version">WhatsApp Bot avanzado | Creado por Kinetic Space Inc.</p>
      <p><span class="online-badge"></span> Estado: En línea</p>
    </header>

    <div class="grid">
      <div class="card">
        <h3>👥 Total de Usuarios</h3>
        <div class="stat-value" id="totalUsers">-</div>
      </div>
      <div class="card">
        <h3>💰 Balance Total</h3>
        <div class="stat-value" id="totalBalance">-</div>
      </div>
      <div class="card">
        <h3>📊 Balance Promedio</h3>
        <div class="stat-value" id="avgBalance">-</div>
      </div>
    </div>

    <div class="leaderboard">
      <h2>🏆 Top 10 Usuarios</h2>
      <table id="leaderboardTable">
        <thead>
          <tr>
            <th>Rango</th>
            <th>Usuario</th>
            <th>Balance</th>
            <th>Nivel</th>
            <th>Reputación</th>
          </tr>
        </thead>
        <tbody id="leaderboardBody">
          <tr>
            <td colspan="5" class="loading">Cargando...</td>
          </tr>
        </tbody>
      </table>
    </div>

    <footer>
      <p>AtlasHub v2.0 • MIT & GPL-3.0 License • github.com/KineticSpaceInc/AtlasHub</p>
    </footer>
  </div>

  <script>
    async function loadStats() {
      try {
        const response = await fetch('/api/stats');
        const data = await response.json();

        document.getElementById('totalUsers').textContent = data.totalUsers;
        document.getElementById('totalBalance').textContent = 
          data.totalBalance.toLocaleString('es-ES', { style: 'currency', currency: 'USD' });
        document.getElementById('avgBalance').textContent = 
          data.avgBalance.toLocaleString('es-ES', { style: 'currency', currency: 'USD' });
      } catch (error) {
        console.error('Error cargando stats:', error);
      }
    }

    async function loadLeaderboard() {
      try {
        const response = await fetch('/api/leaderboard/balance?limit=10');
        const data = await response.json();

        const tbody = document.getElementById('leaderboardBody');
        tbody.innerHTML = '';

        data.forEach((user, index) => {
          const row = tbody.insertRow();
          row.innerHTML = \`
            <td>#\${index + 1}</td>
            <td>\${user.username || user.id}</td>
            <td>$\${user.balance.toLocaleString('es-ES')}</td>
            <td>\${user.level}</td>
            <td>\${user.reputation}</td>
          \`;
        });
      } catch (error) {
        console.error('Error cargando leaderboard:', error);
        document.getElementById('leaderboardBody').innerHTML = 
          '<tr><td colspan="5" class="error">Error cargando leaderboard</td></tr>';
      }
    }

    // Cargar datos
    loadStats();
    loadLeaderboard();

    // Actualizar cada 30 segundos
    setInterval(loadStats, 30000);
    setInterval(loadLeaderboard, 30000);
  </script>
</body>
</html>
    `;
  }

  start(port) {
    this.app.listen(port, () => {
      logger.success(`Panel web disponible en http://localhost:${port}`);
    });
  }
}

export default WebPanel;
