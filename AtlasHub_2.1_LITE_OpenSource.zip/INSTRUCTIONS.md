/*!
 * Atlas Hub v2.0
 * https://github.com/KineticSpaceInc/AtlasHub/
 * (c) 2026 Kinetic Space Inc.
 * Released under MIT & GPL-3.0 License
 */

# 🚀 ATLASHSHUB 2.0 - INSTALACIÓN LOCAL & GITHUB

## ¿Cómo funciona?

**AtlasHub 2.0 está 100% preparado para:**
- ✅ Clonar desde GitHub y usar inmediatamente
- ✅ Usar en tu máquina local sin complicaciones
- ✅ Subir tus cambios y que funcione igual

**NO requiere:**
- ❌ Cambios de rutas
- ❌ Configuraciones especiales por plataforma
- ❌ Variables de entorno complejas

---

## 📥 OPCIÓN 1: USAR DESDE GITHUB

### Paso 1: Clonar
```bash
git clone https://github.com/KineticSpaceInc/AtlasHub.git
cd AtlasHub
```

### Paso 2: Instalar dependencias
```bash
npm install
```

### Paso 3: Configurar
Edita `.env` y reemplaza tu número:
```env
OWNER_ID=5491234567890@c.us
```

### Paso 4: Iniciar
```bash
npm start
```

Escanea el código QR y ¡listo! ✅

---

## 💻 OPCIÓN 2: USAR LOCAL (Sin GitHub)

### Paso 1: Descargar archivos
Descarga todos los archivos de AtlasHub a una carpeta:
```
tu_carpeta/
├── index.js
├── package.json
├── .env
├── .gitignore
├── core/
│   ├── db.js
│   ├── economy.js
│   ├── games.js
│   ├── commands.js
│   ├── utils.js
│   └── logger.js
└── panel/
    └── server.js
```

### Paso 2: Abrir terminal
En la carpeta de AtlasHub:
```bash
# Windows
Shift + Click derecho → "Abrir PowerShell aquí"

# Mac/Linux
cd /ruta/de/tu_carpeta
```

### Paso 3: Instalar dependencias
```bash
npm install
```

### Paso 4: Configurar
Abre `.env` con tu editor favorito (Notepad, VSCode, etc):
```env
OWNER_ID=5491234567890@c.us
```
Reemplaza con tu número de WhatsApp.

### Paso 5: Iniciar
```bash
npm start
```

Escanea el código QR y ¡funciona! ✅

---

## 🔄 OPCIÓN 3: SUBIR TUS CAMBIOS A GITHUB

Si clonaste desde GitHub y quieres contribuir:

### Paso 1: Crea tu rama
```bash
git checkout -b feature/mi-mejora
```

### Paso 2: Haz tus cambios
Modifica los archivos que necesites.

### Paso 3: Commit
```bash
git add .
git commit -m "Agrego nueva funcionalidad"
```

### Paso 4: Push
```bash
git push origin feature/mi-mejora
```

### Paso 5: Pull Request
Ve a GitHub y abre un PR. ¡Listo! 🎉

---

## 🔧 TROUBLESHOOTING

### "npm no se encuentra"
Instala Node.js desde: https://nodejs.org/

### "Código QR no funciona"
```bash
rm -rf .wwebjs_auth
npm start
```

### "Puerto 3000 en uso"
Edita `.env`:
```env
PORT=3001
```

### "Error de módulos"
```bash
rm -rf node_modules package-lock.json
npm install
```

---

## 📁 Estructura de Carpetas

```
AtlasHub/
├── .wwebjs_auth/          (Generado al iniciar)
├── data/                  (Generado al iniciar)
│   └── atlashub.db       (Base de datos SQLite)
├── core/
│   ├── logger.js
│   ├── db.js
│   ├── economy.js
│   ├── games.js
│   ├── commands.js
│   └── utils.js
├── panel/
│   └── server.js
├── index.js
├── package.json
├── .env                   (⚠️ EDITA ESTO)
├── .gitignore
└── README.md
```

---

## ✅ ¿Cómo saber que funciona?

Cuando inices, deberías ver:

```
✅ Base de datos inicializada correctamente
ℹ️ Iniciando AtlasHub 2.0...
ℹ️ Escanea este código QR con WhatsApp:
[CÓDIGO QR AQUÍ]
✅ AtlasHub 2.0 está listo!
✅ Cuenta: Tu Nombre
✅ Panel web disponible en http://localhost:3000
```

Luego:
1. Abre https://web.whatsapp.com en tu navegador
2. Escanea el código QR
3. En cualquier grupo o privado, escribe: `!help`
4. El bot debe responder con la lista de comandos

¡Eso es todo! 🎉

---

## 🌐 PANEL WEB

Una vez corriendo, abre: **http://localhost:3000**

Verás:
- 📊 Estadísticas en tiempo real
- 🏆 Top 10 usuarios
- 💰 Balance total
- 📈 Gráficos

---

## 📞 SOPORTE

Si algo no funciona:

1. Lee **INSTALACION.md**
2. Lee **README.md**
3. Abre un issue en GitHub: https://github.com/KineticSpaceInc/AtlasHub/issues

---

## 🎯 RESUMEN

| Opción | Comando | Tiempo |
|--------|---------|--------|
| **GitHub** | `git clone && npm install && npm start` | 5 min |
| **Local** | Descargar + npm install && npm start | 5 min |
| **Modificar** | Editar archivos + git push | ∞ |

**Todos funcionan EXACTAMENTE igual.** ✅

---

**AtlasHub 2.0** - Creado para ser simple, potente y profesional ⚡

Hecho con ❤️ por **Kinetic Space Inc.**
